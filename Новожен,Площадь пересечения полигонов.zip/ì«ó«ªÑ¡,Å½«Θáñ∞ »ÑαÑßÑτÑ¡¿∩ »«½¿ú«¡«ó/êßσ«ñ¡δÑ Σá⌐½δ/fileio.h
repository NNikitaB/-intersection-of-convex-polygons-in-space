#ifndef FILEIO_H_INCLUDED
#define FILEIO_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include"LIST_K.h"
int fprint_poligon(FILE *f,List *p1);
int fscan_poligon(FILE *f ,List *p1);
#endif // FILEIO_H_INCLUDED
